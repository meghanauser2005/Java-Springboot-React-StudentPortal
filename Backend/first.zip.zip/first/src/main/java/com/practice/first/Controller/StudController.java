package com.practice.first.Controller;


import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.practice.first.Model.Student;
import com.practice.first.Service.StudService;

@RestController
@RequestMapping("/students")
public class StudController{
    private final StudService studService;
    public StudController(StudService studService){
        this.studService=studService;
    }
    @PostMapping
    public Student createStudent(@RequestBody Student student){
        return studService.createStudent(student);
    }
    @GetMapping
    public List<Student> getStudents(){
        return studService.getAllStudents();
    }
}
